# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
risk_prepared = dataiku.Dataset("risk_prepared")
risk_prepared_df = risk_prepared.get_dataframe()

risk_prepared_df["log_amount"] = np.log1p(risk_prepared_df["amount"])
risk_prepared_code_df = risk_prepared_df # For this sample code, simply copy input to output


# Write recipe outputs
risk_prepared_code = dataiku.Dataset("risk_prepared_code")
risk_prepared_code.write_with_schema(risk_prepared_code_df)